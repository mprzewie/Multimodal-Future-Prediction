#include <cstdlib>

int main() {
    int i = std::abs(1);
    long j = std::labs(1L);
    long k = std::abs(1L);
    return 0;
}
