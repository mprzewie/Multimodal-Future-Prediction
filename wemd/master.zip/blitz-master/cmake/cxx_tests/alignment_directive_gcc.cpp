int main() {
    int __attribute__ ((aligned (16))) var;
    var=0;
}
