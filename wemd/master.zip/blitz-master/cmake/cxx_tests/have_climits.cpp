#include <climits>

int main() {
    int i = INT_MIN;
    return 0;
}
