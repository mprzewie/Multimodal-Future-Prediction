int main() {
    __declspec(align(16)) int var;
    var=0;
}
