#include <blitz/array.h>

using namespace blitz;

int main()
{
}

