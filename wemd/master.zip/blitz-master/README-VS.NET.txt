The Blitz configuration file and Microsoft Visual Studio solution files
can be generated with CMake.
