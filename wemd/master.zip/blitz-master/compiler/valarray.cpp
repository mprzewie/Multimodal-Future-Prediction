// valarray<T> class

#include <valarray>

#ifndef BZ_NO_NAMESPACES
using namespace std;
#endif

int main()
{
    valarray<float> x(100);
    return 0;
}

